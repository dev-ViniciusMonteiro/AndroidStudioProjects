package com.vinicius.linuxplay;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class Jogo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jogo);
    }
    public void TelaJogar(View view){
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);

    }
    public void pedra(View view){
        limpar();
        //limpar()= limpa a imagem antiga e traz de volta a imagem sem broda
        ImageView imagemESCOLHA1 = (ImageView) findViewById(R.id.imageView2);
        imagemESCOLHA1.setImageResource(R.drawable.pedra22);
        //seleciona a imagem escolhida com a borda preta
        this.opcaoSelecionada(1);
        //coloca na funcao a opcao escolhida pelo jogador
    }
    public void papel(View view){
        limpar();
        ImageView imagemESCOLHA2 = (ImageView) findViewById(R.id.imageView3);
        imagemESCOLHA2.setImageResource(R.drawable.pedra32);
        this.opcaoSelecionada(2);
    }
    public void tesoura(View view){
        limpar();
        ImageView imagemESCOLHA3 = (ImageView) findViewById(R.id.imageView4);
        imagemESCOLHA3.setImageResource(R.drawable.pedra42);
        this.opcaoSelecionada(3);
    }
    public void opcaoSelecionada(int escolha){
        ImageView imagemBOT = (ImageView) findViewById(R.id.imageView);
        //declara uma imagem com nome imagembot e passa id da imagem
        TextView textoVencedor = (TextView) findViewById(R.id.Escolha);
        //declara um texto se venceu ou perdeu e atribui a texto de id escolha
        int[] opcoes = {1,2,3};//cria um arrei inteiro com 3 numeros(1 2 3)
        int escolhaBOT = new Random().nextInt(3); //cria um numero randomico inteiero de 1 a 3
        int escolhaAPP = opcoes[escolhaBOT];//comparo o numero obtido com o arrei e retorno apenas o numero obtido no inteiro como escolhaAPP

        switch (escolhaAPP){//coloco a imagem dependendo do caso
            case 1:
                imagemBOT.setImageResource(R.drawable.pedra2);
                break;
            case 2:
                imagemBOT.setImageResource(R.drawable.pedra3);
                break;
            case 3:
                imagemBOT.setImageResource(R.drawable.pedra4);
                break;

        }
        if(escolhaAPP==escolha){

            textoVencedor.setText("EMPATE.");

        }else {
            if ((escolhaAPP == 1 && escolha == 2) || (escolhaAPP == 2 && escolha == 3) || (escolhaAPP == 3 && escolha == 1)) {

                textoVencedor.setText("VOCÊ GANHOU.");

            } else {
                textoVencedor.setText("PERDEU.");
            }
        }

    }
    public void limpar(){
        ImageView imagemESCOLHA1 = (ImageView) findViewById(R.id.imageView2);
        imagemESCOLHA1.setImageResource(R.drawable.pedra2);
        ImageView imagemESCOLHA2 = (ImageView) findViewById(R.id.imageView3);
        imagemESCOLHA2.setImageResource(R.drawable.pedra3);
        ImageView imagemESCOLHA3 = (ImageView) findViewById(R.id.imageView4);
        imagemESCOLHA3.setImageResource(R.drawable.pedra4);

    }
}
