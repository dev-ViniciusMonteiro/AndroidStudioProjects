package com.vinicius.linuxplay;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class Como extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_como);
    }
public void LinkLinux(View view)
    {
        Intent brauserIntent= new Intent(Intent.ACTION_VIEW, Uri.parse("https://pt.wikihow.com/Instalar-o-Linux"));
        startActivity(brauserIntent);
    }
    public void VoltarTela(View view)
    {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);

    }
}
