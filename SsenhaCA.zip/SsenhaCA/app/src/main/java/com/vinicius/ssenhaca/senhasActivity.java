package com.vinicius.ssenhaca;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class senhasActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_senhas);
    }
    public void chamar2(View view){

        Intent intent = new Intent(this, MotivoActivity.class);
        startActivity(intent);

    }
    public void chamar6(View view){

        Intent intent = new Intent(this, faqActivity.class);
        startActivity(intent);

    }
    public void chamarA(View view){

        Intent intent = new Intent(this, Aluno.class);
        startActivity(intent);

    }
}
