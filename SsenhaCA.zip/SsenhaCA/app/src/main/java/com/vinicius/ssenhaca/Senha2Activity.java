package com.vinicius.ssenhaca;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Senha2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_senha2);
    }
    public void chamar4(View view){

        Intent intent = new Intent(this, senhasActivity.class);
        startActivity(intent);

    }
    public void chamar9(View view){

        Intent intent = new Intent(this, faqActivity.class);
        startActivity(intent);

    }
    public void chamarA(View view){

        Intent intent = new Intent(this, Aluno.class);
        startActivity(intent);

    }
}
